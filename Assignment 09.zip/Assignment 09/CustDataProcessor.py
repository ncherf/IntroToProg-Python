if __name__ == "__main__":
    raise Exception("This is only for import")
#------------DataProcessor.py ---------------#
#Desc:  Classes that read and write data
#Dev:   Nick Cherf
#Date:  06/01/2017
#ChangeLog:(When,Who,What)
#----------------------------------------#

class File(object):
    """ Process data using files """
    #-------------------------------------#
    #Desc:  Process data using a file
    #Dev:   Nick Cherf
    #Date:  06/01/2017
    #ChangeLog:(When,Who,What)
    #-------------------------------------#

    #--Fields--
    #FileName = name of file
    #TextData = data read from and written to file

    #--Constructor--
    def __init__(self, FileName = "CustomerData.txt", TextData = "Nick's Default Text"):
        #--Attributes--
        self.__FileName = FileName
        self.__TextData = TextData

    #--Properties--
    @property
    def FileName(self):
        return self.__FileName

    @FileName.setter
    def FileName(self, Value):
        self.__FileName = Value

    @property
    def TextData(self):
        return self.__TextData

    @TextData.setter
    def TextData(self, Value):
        self.__TextData = Value

    #--Methods--
    def SaveFile(self):
        try:
            objFile = open(self.FileName, "a")
            objFile.write(self.TextData)
            objFile.close()
        except Exception as e:
            print("Exception: " + str(e))
        return "Data Saved"

    def ReadFile(self):
        try:
            objFile = open(self.FileName, "r")
            self.TextData = objFile.read()
            objFile.close()
        except Exception as e:
            print("Exception: " + str(e))
        return self.TextData

    def ToString(self):
        return self.TextData

    def __str__(self):
        return self.ToString()

# End of Class/Module
