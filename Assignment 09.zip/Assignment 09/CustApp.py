if __name__ == "__main__":
    import CustDataProcessor, Customers
else:
    raise Exception("This file was not meant for import")

# __DATA__
lstEmps = []


# __PROCESSING__

def NewCustomer(First, Last, IceCream):
    try:
        objC = Customers.Customer()
        objC.IceCream = IceCream
        objC.FirstName = First
        objC.LastName = Last

        objL = Customers.CustomerList()
        objL.AddCustomer(objC)

        print(objL.ToString())

    except Exception as e:
        print(e)


def SaveFile():
    try:
        objFile = CustDataProcessor.File()
        objFile.FileName = "CustomerData.txt"
        objFile.TextData = Customers.CustomerList.ToString()

        objFile.SaveFile()

    except Exception as e:
        print(e)

def ReadFile():
    try:
        objFile = CustDataProcessor.File()
        objFile.ReadFile()
        print(str(objFile))
    except Exception as e:
        print(e)

# __INPUT / OUTPUT

while(True):
    print("\nMAIN MENU FOR CUSTOMERS\n"
          "0. Exit Program\n"
          "1. Add Customers\n"
          "2. Save File\n"
          "3. Read File")
    intChoice = int(input("Selection: "))
    if intChoice == 0:
        print("Goodbye")
        break

    elif intChoice == 1:
        strFirstName = input("Please enter Customer's First Name: ")
        strLastName = input("Please enter Customer's Last Name: ")
        strIceCream = input("Please enter Customer's Favorite Ice Cream Flavor: ")
        NewCustomer(strFirstName, strLastName, strIceCream)

    elif intChoice == 2:
        print("\nFile Saved")
        SaveFile()

    elif intChoice == 3:
        print()
        ReadFile()

    else:
        print("Invalid Choice. Please Select Again")
