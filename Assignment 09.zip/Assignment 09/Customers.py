import Persons

if __name__ == "__main__":
    raise Exception("This is only for import")

class Customer(Persons.Person):
# --Fields--
    #IceCream = 0

    # --Constructor--
    def __init__(self, IceCream = ""):
        # Attributes
        self.__IceCream = IceCream

    # --Properties--
    @property
    def IceCream(self):
        return self.__IceCream

    @IceCream.setter
    def IceCream(self, Value):
        self.__IceCream = Value


    # Method
    def ToString(self):
        strCus = super().ToString()
        return str(self.IceCream) + ", " + strCus + "\n"

    def __str__(self):
        return self.ToString()

class CustomerList(object):
    __lstCustomers = []

    @staticmethod
    def AddCustomer(Customer):
        CustomerList.__lstCustomers.append(Customer)

    @staticmethod
    def ToString():
        strData = ""
        for item in CustomerList.__lstCustomers:
            strData += item.FirstName + ", " + item.LastName + ", " + item.IceCream + "\n"
        return strData

    @staticmethod
    def __str__():
        strData = CustomerList.ToString
        return strData