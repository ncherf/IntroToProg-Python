if __name__ == "__main__":
    raise Exception("This is only for import")

class Person(object):
    """ Base Class for Personal data """
    # -------------------------------------#
    # Desc:  Holds Personal data
    # Dev:   RRoot
    # Date:  12/12/2012
    # ChangeLog:(When,Who,What)
    # 05/27/17,Nick Cherf,Added Last Name
    # 05/27/17 6:50 AM, Nick Cherf, Added Constructer and attributes
    # 05/27/17 7:21 AM, Nick Cherf, Added private attributes, property procedures
    # 06/02/17 Repurposed as Module for Lab 09-2
    # -------------------------------------#


    # --Fields--
    #FirstName = ""
    #LastName = ""

    # --Constructor--
    def __init__(self, FirstName = "", LastName = ""):
        # Attributes
        self.__FirstName = FirstName
        self.__LastName = LastName

    # --Properties--
    @property
    def FirstName(self):
        return self.__FirstName

    @FirstName.setter
    def FirstName(self, Name):
        self.__FirstName = Name


    @property
    def LastName(self):
        return self.__LastName

    @LastName.setter
    def LastName(self, Name):
        self.__LastName = Name

    # Method
    def ToString(self):
        return self.FirstName +", " + self.LastName

    def __str__(self):
        return self.ToString()

    # -- End of Class