'''
Now that you have reviewed the websites and videos, try to do the following task. 
This project is very like the last one, but this time you will place the code you 
created for working with your ToDo.txt file into Functions and a Class. 

NOTE: Just in case you had problems with the last one, I have provided my answer 
script in the Module’s zip file! You can use either my script or your script for 
module 5 to get started.

For example, here is the pseudo code from my answer file. I would make step into
 its own function, looking for ways to remove any redundant code.
'''


# -- Data

objFile = None # File handling object
myKey = None # Dictionary Keys
myValue = None # Dictionary Value
dicRow = {} # Dictionary
strChoice = None # Menu Options
strTodo = None # ToDo (key) to add
strPri = None # Priority (value) to add
strDel = None # ToDo (key) to delete


# -- Processing

class ToDo(object):
    # This class includes all methods used in this script

    @staticmethod
    def readFile(FileName = "ToDo.txt"):
        # This method opens a file and reads its comma separated values into a dictionary

        objFile = open(str(FileName), "r")

        for row in objFile:
            index = row.index(",")
            strTodo = row[0:index]
            strPri = row[index + 1:]
            dicRow[strTodo.strip("\n")] = strPri.strip("\n")
        return dicRow

        objFile.close()


    @staticmethod
    def addTodo(myKey, myValue):
        # This method adds a Todo and a Priority to the dictionary
        if myKey not in dicRow.keys():
            dicRow[myKey] = myValue
            return myKey + " added to ToDo list with " + myValue + " priority."
        else:
            return "Todo already exists."


    @staticmethod
    def delTodo(myKey):
        # This method removes a Todo and a Priority from the dictionary
        if strDel in dicRow:
            del dicRow[myKey]
            return strDel + " deleted from ToDo list."
        else:
            return "Can't find " + strDel + " in ToDo list."

    @staticmethod
    def saveTodo(FileName):
        # This method saves the file
        objFile = open(str(FileName), "w")

        for myKey, myValue in dicRow.items():
            strData = myKey + "," + myValue + "\n"
            objFile.write(strData)

        objFile.close()

        return "ToDo.txt has been updated."

# Read the file into memory
dicRow = ToDo.readFile("ToDo.txt")

# -- Presentation

# Display a menu of choices to the user
while (True):
    print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3
    # Display all todo items to user

    if (strChoice.strip() == '1'):
        for myKey, myValue in dicRow.items():
            print((myKey, " = ", myValue, "priority."))
        continue


    # Step 4 - Add a new item to the list/Table

    elif (strChoice.strip() == '2'):
        strTodo = input("Please enter a todo item: ")
        strPri = input("Please enter a priority for the item: ")

        added = ToDo.addTodo(strTodo, strPri)
        added
        print(added)

        continue


    # Step 5 - Remove a new item to the list/Table

    elif (strChoice == '3'):
        strDel = input("Please select a ToDo item to delete. ")

        deleted = ToDo.delTodo(strDel)
        deleted
        print(deleted)

        continue


    # Step 6 - Save tasks to the ToDo.txt file

    elif (strChoice == '4'):
        updated = ToDo.saveTodo("ToDo.txt")
        updated
        print(updated)

        continue
    

    elif (strChoice == '5'):
        break  # and Exit the program