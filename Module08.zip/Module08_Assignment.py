
class Product(object):
    """ Base Class for Product data """
    # -------------------------------------#
    # Desc:  Holds Product Data
    # Dev:   Nick Cherf
    # Date:  5/28/2017
    # ChangeLog:(When,Who,What)
    #
    # -------------------------------------#

    # -- Constructor
    def __init__(self, UserInput):
        # -- Attributes
        self.__UserInput = UserInput

    # -- Properties
    @property
    def UserInput(self):
        return self.__UserInput

    @UserInput.setter
    def UserInput(self, Input):
        self.__UserInput = Input

    # -- Methods
    def ToString(self):
        return self.UserInput + "\n"

    def __str__(self):
        return self.ToString()

class FileHandler(Product):
    """ Reads and Writes Product data to a file"""
    # -------------------------------------#
    # Desc:  Reads/Writes Product Data
    # Dev:   Nick Cherf
    # Date:  5/28/2017
    # ChangeLog:(When,Who,What)
    #
    # -------------------------------------#

    #Field
    objFile = None  # File Handle

    @staticmethod
    def WriteProductUserInput(File, Input):
        objFile = open(File, "w")
        objFile.write(Input)
        objFile.close()

    @staticmethod
    def ReadAllFileData(File, Message="Contents of File"):
        print(Message)
        objFile = open(File, "r")
        print(objFile.read())
        objFile.close()


#Data
strUserInput = None #A string which holds user input
strOutput = ""

#I/O
FileHandler.ReadAllFileData("Products.txt")
input("Press Enter to Write New Product Details")

print("Type in a Product Id, Name, and Price you want to add to the file")
print("(Enter 'Exit' to quit!)")
while(True):
      strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
      if(strUserInput.lower() == "exit"):
          break
      else:
          objLine = Product(strUserInput)
          strOutput += str(objLine)

FileHandler.WriteProductUserInput("Products.txt", strOutput)
print()
FileHandler.ReadAllFileData("Products.txt")