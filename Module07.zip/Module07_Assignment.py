import pickle

# -- Data
pfob = None # Pickle File Object
lstMath = [] #List Object
fileName = "MyMath.dat" # File

# -- Processing

class myMath(object):

    @staticmethod
    def mathData (fileName):
        # Menu Item 1: Divide Numbers from File
        try:
            # Load bianary file, read it into list
            pfob = open(fileName, "rb")
            lstMath = pickle.load(pfob)
            pfob.close()

            motto = lstMath[0]
            num1 = float(lstMath[1])
            num2 = float(lstMath[2])

            divided = num1 / num2

            phrase = 'Your math motto is: "' + motto.strip(".") + '." ' + str(num1) + " divided by " + str(num2) + " is " + str(divided) + "!"

            return phrase

        except FileNotFoundError as e:
            print("Couldn't find the data file. Please create one using Option 2")
            print("In Python's words, " + str(e))
        except ValueError as e:
            print("The file contained a string when it expected numbers.\n\
                  Please edit the file so that the first and second numbers are both numbers (not characters)!")
        except ZeroDivisionError as e:
            print("The file has a 0 for the second number.\n\
                  Please edit the file so that the second number is not 0!")
        except Exception as e:
            print("Error!")
            print("Specifically, " + str(e))

    @staticmethod
    def replaceData (fileName, motto, num1, num2):
        # Menu Item 2: Replace data in list
        try:
            lstReplace = [motto, num1, num2]

            pfob = open(fileName, "wb")
            pickle.dump(lstReplace, pfob)

            return lstReplace
        except FileNotFoundError as e:
            print("Couldn't find the data file.")
            print("In Python's words, " + str(e))
        except Exception as e:
            print("Error!")
            print("Specifically, " + str(e))

    # -- Presentation

# Menu items

while (True):
    # Menu Items
    print("""
    OPTIONS
    1. Divide numbers from your file
    2. Create/Edit data file
    3. Exit
    """)

    strChoice = input('Please select either 1, 2, or 3: ')

    # Display data
    if (strChoice.strip() == "1"):
        lstDivide = myMath.mathData(fileName)
        lstDivide
        print(lstDivide)

        continue

    # Replace data
    elif (strChoice.strip() == "2"):
        motto = input('Enter your Math Motto (ex., "I ADDore math"): ')
        num1 = input("Enter your first number: ")
        num2 = input("Enter your second number: ")

        replaced = myMath.replaceData(fileName, motto, num1, num2)

        replaced

        print("\nCurrent file contents:")
        print(replaced)

        continue

    # Exit
    elif (strChoice.strip() == "3"):
        break


